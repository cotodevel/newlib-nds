int LogoConvert(unsigned char *srcp, unsigned char *dstp, unsigned char white);
