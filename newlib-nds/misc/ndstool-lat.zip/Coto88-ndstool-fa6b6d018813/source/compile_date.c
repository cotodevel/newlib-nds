const char CompileDate[] = __DATE__;
