void Hook(char *ndsfilename, char *arm7filename);
