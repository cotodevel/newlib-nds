This folder contains the freeimage files required for building git on windows.
FreeImage.lib is for linking with msvc, libFreeImage.a is the library for
linking with MinGW.

Linux and OSX users should build and install FreeImage from source before
building git.

