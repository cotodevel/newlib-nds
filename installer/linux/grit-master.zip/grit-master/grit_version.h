#ifndef GRIT_VERSION
#define GRIT_VERSION "0.8.14"
#endif

#ifndef GRIT_BUILD
#define GRIT_BUILD "20171601"
#endif
